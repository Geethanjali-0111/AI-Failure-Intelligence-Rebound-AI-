# AI Failure Intelligence Prototype

A demo-ready prototype that turns natural-language failure reflections into structured insights, recurring patterns, and recovery actions.

## Features
- Failure dashboard
- Natural-language failure logger
- Local NLP extraction
- Root-cause analysis
- Pattern insights
- Personalized recovery plan
- Demo history and REST API

## Run backend
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
```

## Run frontend
```bash
cd frontend
npm install
npm run dev
```

Open the Vite URL shown in the terminal.

The prototype intentionally works without an API key. The analysis layer is transparent and can later be replaced by an LLM provider.
