# API
GET /health
GET /failures
POST /analyze — body: {"text":"I failed a software interview after preparing for 5 days..."}
POST /failures — saves an analyzed Failure object.
