# 3-minute demo
1. Open Dashboard and show demo history.
2. Open Log a setback.
3. Enter: “I attended a software interview yesterday. I failed the technical round. They asked Arrays and Trees. I prepared for 5 days and became nervous.”
4. Click Analyze with AI.
5. Show extracted event, preparation and causes.
6. Save to history.
7. Open Insights and show recurring causes.
8. Open Recovery and explain Evidence → Pattern → Action.
