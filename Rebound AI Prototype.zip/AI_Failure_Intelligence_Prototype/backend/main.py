from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List
import re,json,os
app=FastAPI(title='AI Failure Intelligence API');app.add_middleware(CORSMiddleware,allow_origins=['*'],allow_methods=['*'],allow_headers=['*'])
FILE=os.path.join(os.path.dirname(__file__),'failures.json')
class Input(BaseModel): text:str
class Failure(BaseModel): event_type:str;outcome:str;summary:str;preparation_days:int=0;root_causes:List[str]=[];topics:List[str]=[];focus:str=''
def analyze(t):
 s=t.lower();typ='Interview' if any(k in s for k in ['interview','technical round','coding round']) else 'Exam' if any(k in s for k in ['exam','semester','test','aptitude']) else 'Other';out='Failed' if any(k in s for k in ['failed','rejected','did not clear',"didn't clear",'not selected']) else 'Unsuccessful';m=re.search(r'(\d+)\s*days?',s);days=int(m.group(1)) if m else 0;topics=[k.title() for k in ['arrays','trees','graphs','dynamic programming','oops','dbms','networking','aptitude','communication','python','java','sql'] if k in s];causes=[]
 if days and days<10: causes.append('Short preparation')
 if any(k in s for k in ['nervous','panic','anxious','confidence']): causes.append('Performance anxiety')
 if any(k in s for k in ["couldn't solve",'could not solve','weak','did not know',"didn't know"]): causes.append('Knowledge gap')
 if any(k in s for k in ['time','timed','too slow']): causes.append('Time management')
 if not causes: causes=['Insufficient evidence — collect another reflection']
 return {'event_type':typ,'outcome':out,'summary':t.strip(),'preparation_days':days,'root_causes':causes,'topics':topics,'focus':', '.join(topics[:3]) or 'Review identified causes and collect more evidence'}
def load():
 if not os.path.exists(FILE): return []
 return json.load(open(FILE))
def save(x): json.dump(x,open(FILE,'w'),indent=2)
@app.get('/health')
def health(): return {'status':'ok','product':'AI Failure Intelligence'}
@app.get('/failures')
def failures(): return load()
@app.post('/analyze')
def analysis(x:Input): return analyze(x.text)
@app.post('/failures')
def add(x:Failure): d=load();d.append(x.model_dump());save(d);return x
